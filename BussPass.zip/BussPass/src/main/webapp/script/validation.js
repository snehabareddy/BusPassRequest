/**
 * 
 */
function validate(){
	var fname=regform.fname.value; 
	var splchar = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?~";
	if(fname.length<4)
		{
		alert("first name must have atleast 6 characters");
		return false;
		}
	if(fname!="" && fname.length>=6)
	{
		for (var i=0;i<fname.length;i++)
		{
			if(splchar.indexOf(fname.charAt(i)) != -1)
			{
			alert ("Userid should not have any special characters");
			return false;
			}
		}
	}

	var lname=regform.lname.value; 
	var splchar = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?~";
	if(lname.length<4)
		{
		alert("first name must have atleast 6 characters");
		return false;
		}
	if(lname!="" && lname.length>=6)
	{
		for (var i=0;i<lname.length;i++)
		{
			if(splchar.indexOf(lname.charAt(i)) != -1)
			{
			alert ("Userid should not have any special characters");
			return false;
			}
		}
	}
	
	//code for email validation
	var emailid=regform.email.value;
	if(emailid.indexOf('@')==-1)
		{
		alert("invalid");
		return false;
		}
	else if((emailid.indexOf('@')==0)||(emailid.indexOf('.')==0)||(emailid.indexOf('@'))>(emailid.indexOf('.')))
		{
		alert("Given email id is invalid"); 
		return false;
		}
	else{
		alert("Given email id is valid");
		}

}